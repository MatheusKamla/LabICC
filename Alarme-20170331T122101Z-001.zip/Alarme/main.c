#include <stdio.h>
#include <stdlib.h>
#include <windows.h>

int main()
{
    int hora, minuto , segundo;
    int h=0, m=0, s=0 ,ls=1 , lm=2, lh=3;
    printf("Digite quando deseja acordar:");
    scanf("%d %d %d", &hora, &minuto, &segundo);
    while(1){
        Sleep(1000);
        s++;
        if(s==segundo){
             ls=0;
        }
        system("cls");
        if(s>59){
            m++;
            s=0;
        }
         if(m==minuto){
            lm=0;
        }
        if(m>59){
            h++;
            m=0;
        }
        if(h==hora){
            lh=0;
            }
        if(h>23){
            h=0;
        }
        if(ls==0 & lm==0 & lh==0){
            printf("\n\n\nAcorda!!! %dh %dmin %ds", h, m, s);
            break;
        }else{
        printf("\n\n\nRelogio: %dh %dmin %ds", h, m, s);
        }

    }
  return 0;
   }




